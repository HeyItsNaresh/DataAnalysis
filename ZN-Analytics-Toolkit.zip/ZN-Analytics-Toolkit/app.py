import io
import re
from math import sqrt
from datetime import datetime


import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from scipy import stats
from statsmodels.formula.api import ols
import statsmodels.api as sm
import matplotlib.pyplot as plt

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, HRFlowable
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

try:
    from wordcloud import WordCloud, STOPWORDS
    WORDCLOUD_AVAILABLE = True
except Exception:
    WORDCLOUD_AVAILABLE = False

APP_NAME = "ZN Analytics Toolkit"
ACCENT = "#F8BBD0"
ACCENT_STRONG = "#F48FB1"
BG = "#0E1117"
CARD = "#161B22"
PANEL = "#1F2937"
BORDER = "#2D3748"
TEXT = "#F8FAFC"
MUTED = "#CBD5E1"

st.set_page_config(page_title=APP_NAME, page_icon="📊", layout="wide")

# ----------------------------- Styling -----------------------------
def inject_css():
    st.markdown(
        f"""
        <style>
            .stApp {{ background: {BG}; color: {TEXT}; }}
            section[data-testid="stSidebar"] {{ background: #0B0F15; border-right: 1px solid {BORDER}; }}
            h1, h2, h3 {{ color: {ACCENT}; letter-spacing: -0.02em; }}
            h4, h5, h6 {{ color: {TEXT}; }}
            .hero {{
                padding: 2.2rem 2rem;
                border-radius: 24px;
                background: linear-gradient(135deg, rgba(248,187,208,0.16), rgba(22,27,34,0.92));
                border: 1px solid rgba(248,187,208,0.35);
                box-shadow: 0 18px 60px rgba(0,0,0,0.28);
                margin-bottom: 1.4rem;
            }}
            .hero-title {{ font-size: 3rem; font-weight: 800; color: {TEXT}; margin-bottom: 0.2rem; }}
            .hero-subtitle {{ font-size: 1.25rem; color: {ACCENT}; font-weight: 650; margin-bottom: 0.8rem; }}
            .hero-body {{ color: {MUTED}; font-size: 1.02rem; max-width: 1000px; }}
            .metric-card {{
                background: {CARD}; padding: 1.1rem; border-radius: 18px;
                border: 1px solid {BORDER}; box-shadow: 0 6px 22px rgba(0,0,0,0.22);
                min-height: 120px;
            }}
            .metric-label {{ color: {MUTED}; font-size: 0.86rem; text-transform: uppercase; letter-spacing: 0.08em; }}
            .metric-value {{ color: {TEXT}; font-size: 1.8rem; font-weight: 800; margin-top: 0.2rem; }}
            .feature-card {{
                background: {CARD}; padding: 1.15rem; border-radius: 18px; border: 1px solid {BORDER};
                min-height: 148px; margin-bottom: 1rem;
            }}
            .feature-card b {{ color: {ACCENT}; font-size: 1.05rem; }}
            .feature-card p {{ color: {MUTED}; margin-top: 0.45rem; }}
            .info-box {{
                background: rgba(248,187,208,0.08); border-left: 4px solid {ACCENT};
                padding: 1rem 1.1rem; border-radius: 12px; color: {MUTED}; margin: 0.6rem 0 1rem 0;
            }}
            .good {{ color: #86efac; font-weight: 700; }}
            .warn {{ color: #fbbf24; font-weight: 700; }}
            .bad {{ color: #fca5a5; font-weight: 700; }}
            div[data-testid="stMetricValue"] {{ color: {TEXT}; }}
            div[data-testid="stMetricLabel"] {{ color: {MUTED}; }}
            .stButton>button {{
                border: 1px solid {ACCENT}; color: {TEXT}; background: rgba(248,187,208,0.12);
                border-radius: 12px; padding: 0.5rem 0.9rem;
            }}
            .stButton>button:hover {{ border-color: {ACCENT_STRONG}; background: rgba(248,187,208,0.22); color: white; }}
            .stDownloadButton>button {{
                border: 1px solid {ACCENT}; color: {TEXT}; background: rgba(248,187,208,0.12);
                border-radius: 12px;
            }}
        </style>
        """,
        unsafe_allow_html=True,
    )

inject_css()

# ----------------------------- Helpers -----------------------------
def format_num(x, decimals=3):
    try:
        if pd.isna(x):
            return "NA"
        return f"{float(x):.{decimals}f}"
    except Exception:
        return str(x)


def format_p(p):
    try:
        if pd.isna(p):
            return "NA"
        return "< 0.001" if p < 0.001 else f"{p:.4f}"
    except Exception:
        return str(p)


def interpret_p(p, alpha=0.05, h0="the null hypothesis"):
    if p < alpha:
        return f"Since p = {format_p(p)} is less than α = {alpha}, reject H₀. The result is statistically significant."
    return f"Since p = {format_p(p)} is greater than or equal to α = {alpha}, fail to reject H₀. The result is not statistically significant."


def clean_numeric(series):
    return pd.to_numeric(series, errors="coerce").dropna()


def numeric_cols(df):
    return df.select_dtypes(include=np.number).columns.tolist()


def categorical_cols(df):
    return df.select_dtypes(include=["object", "category", "bool"]).columns.tolist()


def text_cols(df):
    cols = []
    for c in categorical_cols(df):
        avg_len = df[c].dropna().astype(str).map(len).mean() if df[c].dropna().shape[0] else 0
        if avg_len >= 12:
            cols.append(c)
    return cols or categorical_cols(df)


def style_fig(fig, title=None):
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor=BG,
        plot_bgcolor=BG,
        font=dict(color=TEXT),
        title=dict(text=title if title else fig.layout.title.text, font=dict(color=ACCENT, size=20)),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        margin=dict(l=30, r=30, t=60, b=35),
    )
    fig.update_xaxes(tickformat=".2f", gridcolor="#263241", zerolinecolor="#334155")
    fig.update_yaxes(tickformat=".2f", gridcolor="#263241", zerolinecolor="#334155")
    return fig


def metric_card(label, value):
    st.markdown(
        f"""
        <div class='metric-card'>
            <div class='metric-label'>{label}</div>
            <div class='metric-value'>{value}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def get_df():
    return st.session_state.get("df", None)


def require_df():
    df = get_df()
    if df is None:
        st.warning("Please load a dataset in the Data Workspace first.")
        return None
    return df


def load_sample():
    try:
        return pd.read_csv("employee_analytics_sample.csv")
    except FileNotFoundError:
        return pd.read_csv("/mnt/data/ZN-Analytics-Toolkit/employee_analytics_sample.csv")


def add_result(test_name, statistic, p_value, interpretation):
    if "results" not in st.session_state:
        st.session_state.results = []
    st.session_state.results.append({
        "Test": test_name,
        "Statistic": statistic,
        "p-value": p_value,
        "Interpretation": interpretation,
    })


def qq_plot(data, title="Q-Q Plot"):
    data = clean_numeric(data)
    if len(data) < 3:
        return None
    osm, osr = stats.probplot(data, dist="norm", fit=False)
    slope, intercept, r = stats.probplot(data, dist="norm", fit=True)[1]
    line_y = slope * np.array(osm) + intercept
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=osm, y=osr, mode="markers", name="Sample quantiles", marker=dict(color=ACCENT)))
    fig.add_trace(go.Scatter(x=osm, y=line_y, mode="lines", name="Reference line"))
    fig.update_layout(xaxis_title="Theoretical quantiles", yaxis_title="Sample quantiles")
    return style_fig(fig, title)


def hist_with_normal(data, col_name="Variable"):
    data = clean_numeric(data)
    fig = px.histogram(x=data, nbins=30, histnorm="probability density", title=f"Histogram with Normal Fit: {col_name}")
    if len(data) > 1:
        mu, sd = data.mean(), data.std(ddof=1)
        x = np.linspace(data.min(), data.max(), 250)
        y = stats.norm.pdf(x, mu, sd)
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", name="Normal fit", line=dict(color=ACCENT, width=3)))
    fig.update_layout(xaxis_title=col_name, yaxis_title="Density")
    return style_fig(fig)


def df_for_pdf_table(df, max_rows=14, max_cols=6):
    out = df.copy()
    if out.shape[1] > max_cols:
        out = out.iloc[:, :max_cols]
    if out.shape[0] > max_rows:
        out = out.head(max_rows)
    return [[str(c) for c in out.columns]] + out.fillna("NA").astype(str).values.tolist()


def matplotlib_image_buffer(fig):
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", bbox_inches="tight", dpi=170, facecolor="#0E1117")
    plt.close(fig)
    buffer.seek(0)
    return buffer


def wordcloud_image_buffer(frequencies, width=1800, height=900):
    """Create a complete, uncropped word-cloud image for PDF export."""
    wc = WordCloud(
        width=width,
        height=height,
        background_color="white",
        colormap="RdPu",
        prefer_horizontal=0.90,
        collocations=False,
        max_words=300,
        margin=12,
        relative_scaling=0.55,
        random_state=42,
    ).generate_from_frequencies(frequencies)
    image = wc.to_image()
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer


def pdf_cell(value, style):
    text = str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(text, style)


def pdf_table(df, body_style, max_rows=20, max_cols=7, col_widths=None):
    out = df.copy()
    if out.shape[1] > max_cols:
        out = out.iloc[:, :max_cols]
    if out.shape[0] > max_rows:
        out = out.head(max_rows)
    header = [pdf_cell(c, body_style) for c in out.columns]
    rows = [[pdf_cell(v, body_style) for v in row] for row in out.fillna("NA").astype(str).values.tolist()]
    table = Table([header] + rows, repeatRows=1, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(ACCENT)),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#111827")),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#CBD5E1")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#FFF7FB")]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return table


def section_header(story, title, styles):
    story.append(Spacer(1, 0.1 * inch))
    story.append(Paragraph(title, styles["SectionZN"]))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor(ACCENT), spaceBefore=2, spaceAfter=8))


def normality_summary_table(df):
    rows = []
    for col in numeric_cols(df):
        data = clean_numeric(df[col])
        if len(data) < 3:
            continue
        sample = data.sample(5000, random_state=42) if len(data) > 5000 else data
        try:
            sh_stat, sh_p = stats.shapiro(sample)
        except Exception:
            sh_stat, sh_p = np.nan, np.nan
        try:
            sd = sample.std(ddof=1)
            ks_stat, ks_p = stats.kstest((sample - sample.mean()) / sd, "norm") if sd > 0 else (np.nan, np.nan)
        except Exception:
            ks_stat, ks_p = np.nan, np.nan
        try:
            ad = stats.anderson(sample, dist="norm")
            crit_5 = ad.critical_values[list(ad.significance_level).index(5.0)] if 5.0 in list(ad.significance_level) else ad.critical_values[2]
            ad_decision = "Reject normality" if ad.statistic > crit_5 else "Fail to reject normality"
        except Exception:
            ad_stat, crit_5, ad_decision = np.nan, np.nan, "Unavailable"
        else:
            ad_stat = ad.statistic
        decision = "Likely non-normal" if (pd.notna(sh_p) and sh_p < 0.05) or (pd.notna(ks_p) and ks_p < 0.05) or ad_decision == "Reject normality" else "No strong evidence against normality"
        rows.append({
            "Variable": col,
            "Shapiro p": format_p(sh_p),
            "K-S p": format_p(ks_p),
            "A-D stat": format_num(ad_stat),
            "A-D 5% crit": format_num(crit_5),
            "Overall interpretation": decision,
        })
    return pd.DataFrame(rows)


def distribution_fit_summary_table(df):
    rows = []
    for col in numeric_cols(df):
        data = clean_numeric(df[col])
        if len(data) < 5 or data.nunique() < 2:
            continue
        counts, bin_edges = np.histogram(data, bins=min(30, max(8, int(np.sqrt(len(data))))), density=True)
        centers = (bin_edges[:-1] + bin_edges[1:]) / 2
        fits = {}
        try:
            mu, sd = data.mean(), data.std(ddof=1)
            fits["Normal"] = float(np.mean((counts - stats.norm.pdf(centers, mu, sd)) ** 2)) if sd > 0 else np.inf
        except Exception:
            fits["Normal"] = np.inf
        try:
            loc, scale = data.min(), data.max() - data.min()
            fits["Uniform"] = float(np.mean((counts - stats.uniform.pdf(centers, loc=loc, scale=scale)) ** 2)) if scale > 0 else np.inf
        except Exception:
            fits["Uniform"] = np.inf
        try:
            loc, scale = stats.expon.fit(data)
            fits["Exponential"] = float(np.mean((counts - stats.expon.pdf(centers, loc=loc, scale=scale)) ** 2)) if scale > 0 else np.inf
        except Exception:
            fits["Exponential"] = np.inf
        best = min(fits, key=fits.get)
        rows.append({
            "Variable": col,
            "Normal MSE": format_num(fits["Normal"], 6),
            "Uniform MSE": format_num(fits["Uniform"], 6),
            "Exponential MSE": format_num(fits["Exponential"], 6),
            "Best fit": best,
            "Interpretation": f"{best} has the lowest MSE among the tested fits.",
        })
    return pd.DataFrame(rows)


def best_fit_plot_buffer(data, col_name):
    data = clean_numeric(data)
    fig, ax = plt.subplots(figsize=(7.0, 4.0))
    counts, bins, _ = ax.hist(data, bins=min(30, max(8, int(np.sqrt(len(data))))), density=True, alpha=0.55, label="Observed data")
    x = np.linspace(data.min(), data.max(), 300)
    if data.std(ddof=1) > 0:
        ax.plot(x, stats.norm.pdf(x, data.mean(), data.std(ddof=1)), label="Normal fit", linewidth=2)
    scale = data.max() - data.min()
    if scale > 0:
        ax.plot(x, stats.uniform.pdf(x, loc=data.min(), scale=scale), label="Uniform fit", linewidth=2)
    try:
        loc, exp_scale = stats.expon.fit(data)
        ax.plot(x, stats.expon.pdf(x, loc=loc, scale=exp_scale), label="Exponential fit", linewidth=2)
    except Exception:
        pass
    ax.set_title(f"Distribution Fit Comparison: {col_name}")
    ax.set_xlabel(col_name)
    ax.set_ylabel("Density")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.25)
    return matplotlib_image_buffer(fig)



def run_clt_simulation(data, sample_size=30, n_simulations=1000, seed=42):
    data = np.asarray(clean_numeric(pd.Series(data)), dtype=float)
    if len(data) < 2:
        return None
    sample_size = int(max(2, sample_size))
    n_simulations = int(max(100, n_simulations))
    rng = np.random.default_rng(seed)
    samples = rng.choice(data, size=(n_simulations, sample_size), replace=True)
    sample_means = samples.mean(axis=1)
    return {
        "sample_means": sample_means,
        "original_mean": float(np.mean(data)),
        "original_std": float(np.std(data, ddof=1)),
        "sampling_mean": float(np.mean(sample_means)),
        "sampling_std": float(np.std(sample_means, ddof=1)),
        "theoretical_se": float(np.std(data, ddof=1) / np.sqrt(sample_size)),
        "sample_size": sample_size,
        "n_simulations": n_simulations,
    }


def clt_plotly_figs(data, col_name, sample_size=30, n_simulations=1000, seed=42):
    data = clean_numeric(pd.Series(data))
    sim = run_clt_simulation(data, sample_size, n_simulations, seed)
    if sim is None:
        return None, None, None
    sample_means = sim["sample_means"]
    fig_original = px.histogram(x=data, nbins=35, histnorm="probability density", title=f"Original Distribution: {col_name}")
    fig_original.update_layout(xaxis_title=col_name, yaxis_title="Density")
    fig_original = style_fig(fig_original)

    fig_sampling = px.histogram(x=sample_means, nbins=35, histnorm="probability density", title=f"Sampling Distribution of Means: n = {sample_size}")
    x = np.linspace(sample_means.min(), sample_means.max(), 300)
    if np.std(sample_means, ddof=1) > 0:
        fig_sampling.add_trace(go.Scatter(
            x=x,
            y=stats.norm.pdf(x, np.mean(sample_means), np.std(sample_means, ddof=1)),
            mode="lines",
            name="Normal curve over sample means",
            line=dict(color=ACCENT, width=3),
        ))
    fig_sampling.update_layout(xaxis_title="Sample mean", yaxis_title="Density")
    fig_sampling = style_fig(fig_sampling)

    fig_qq = qq_plot(pd.Series(sample_means), title="Q-Q Plot of Sample Means")
    return fig_original, fig_sampling, fig_qq


def clt_plot_buffer(data, col_name, sample_size=30, n_simulations=1000, seed=42):
    data = clean_numeric(pd.Series(data))
    sim = run_clt_simulation(data, sample_size, n_simulations, seed)
    if sim is None:
        return None
    sample_means = sim["sample_means"]
    fig, axes = plt.subplots(2, 1, figsize=(7.0, 6.2))
    axes[0].hist(data, bins=min(35, max(8, int(np.sqrt(len(data))))), density=True, alpha=0.70)
    axes[0].set_title(f"Original Distribution: {col_name}")
    axes[0].set_xlabel(col_name)
    axes[0].set_ylabel("Density")
    axes[0].grid(alpha=0.25)

    axes[1].hist(sample_means, bins=35, density=True, alpha=0.70, label="Sample means")
    x = np.linspace(sample_means.min(), sample_means.max(), 300)
    if np.std(sample_means, ddof=1) > 0:
        axes[1].plot(x, stats.norm.pdf(x, np.mean(sample_means), np.std(sample_means, ddof=1)), linewidth=2, label="Normal curve")
    axes[1].set_title(f"Sampling Distribution of Means: n = {sample_size}, simulations = {n_simulations}")
    axes[1].set_xlabel("Sample mean")
    axes[1].set_ylabel("Density")
    axes[1].legend(fontsize=8)
    axes[1].grid(alpha=0.25)
    fig.tight_layout()
    return matplotlib_image_buffer(fig)


def generate_pdf_report(df):
    if not REPORTLAB_AVAILABLE:
        return None
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=34, leftMargin=34, topMargin=34, bottomMargin=34)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CoverTitleZN", parent=styles["Title"], textColor=colors.HexColor("#FFFFFF"), fontSize=27, leading=31, alignment=1, spaceAfter=12))
    styles.add(ParagraphStyle(name="CoverSubZN", parent=styles["BodyText"], textColor=colors.HexColor(ACCENT), fontSize=13, leading=17, alignment=1, spaceAfter=12))
    styles.add(ParagraphStyle(name="SectionZN", parent=styles["Heading2"], textColor=colors.HexColor(ACCENT_STRONG), fontSize=15, leading=18, spaceBefore=10, spaceAfter=5))
    styles.add(ParagraphStyle(name="SubSectionZN", parent=styles["Heading3"], textColor=colors.HexColor("#374151"), fontSize=11.5, leading=14, spaceBefore=8, spaceAfter=4))
    styles.add(ParagraphStyle(name="BodyZN", parent=styles["BodyText"], textColor=colors.HexColor("#111827"), fontSize=9.2, leading=12))
    styles.add(ParagraphStyle(name="SmallZN", parent=styles["BodyText"], textColor=colors.HexColor("#374151"), fontSize=7.6, leading=9.3))
    styles.add(ParagraphStyle(name="CalloutZN", parent=styles["BodyText"], textColor=colors.HexColor("#111827"), backColor=colors.HexColor("#FFF1F7"), borderColor=colors.HexColor(ACCENT), borderWidth=0.5, borderPadding=8, fontSize=9.2, leading=12, spaceBefore=6, spaceAfter=8))

    story = []

    # Cover page
    cover = Table([
        [Paragraph("ZN Analytics Toolkit", styles["CoverTitleZN"])],
        [Paragraph("From raw data to statistical insight", styles["CoverSubZN"])],
        [Paragraph("A full-session analysis report generated from the current toolkit outputs, including data quality, descriptive analytics, graphical summaries, distribution fitting, Central Limit Theorem simulation, normality testing, statistical outputs, interpretations, and export-ready insights.", styles["CoverSubZN"])],
    ], colWidths=[7.25 * inch])
    cover.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(BG)),
        ("BOX", (0, 0), (-1, -1), 1.2, colors.HexColor(ACCENT)),
        ("TOPPADDING", (0, 0), (-1, -1), 28),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 24),
        ("LEFTPADDING", (0, 0), (-1, -1), 18),
        ("RIGHTPADDING", (0, 0), (-1, -1), 18),
    ]))
    story.append(cover)
    story.append(Spacer(1, 0.25 * inch))
    identity = pd.DataFrame({"Field": ["Created by", "Course", "University", "Generated"], "Details": ["Naresh Punjabi", "Tools and Methods of Data Analysis", "SRH University Leipzig", datetime.now().strftime("%Y-%m-%d %H:%M")]})
    story.append(pdf_table(identity, styles["BodyZN"], max_rows=4, max_cols=2, col_widths=[1.5 * inch, 5.75 * inch]))
    story.append(PageBreak())

    total_cells = df.shape[0] * df.shape[1]
    missing_cells = int(df.isna().sum().sum())
    missing_pct = (missing_cells / total_cells * 100) if total_cells else 0
    dupes = int(df.duplicated().sum())
    nums = numeric_cols(df)
    cats = categorical_cols(df)

    section_header(story, "1. Executive Summary", styles)
    story.append(Paragraph(
        f"This report summarizes the current analysis session for a dataset containing <b>{df.shape[0]}</b> rows and <b>{df.shape[1]}</b> columns. "
        f"The dataset has <b>{missing_cells}</b> missing cells ({missing_pct:.2f}%) and <b>{dupes}</b> duplicate rows. "
        f"The toolkit detected <b>{len(nums)}</b> numeric variables and <b>{len(cats)}</b> categorical/text variables. "
        "All numerical results are rounded for readability, and the graphical outputs are formatted for report presentation.", styles["CalloutZN"]
    ))
    summary_cards = pd.DataFrame({
        "Metric": ["Rows", "Columns", "Missing cells", "Missing %", "Duplicate rows", "Numeric columns", "Categorical/Text columns"],
        "Value": [df.shape[0], df.shape[1], missing_cells, f"{missing_pct:.2f}%", dupes, len(nums), len(cats)]
    })
    story.append(pdf_table(summary_cards, styles["BodyZN"], max_rows=10, max_cols=2, col_widths=[2.6 * inch, 2.0 * inch]))

    section_header(story, "2. Data Workspace Output", styles)
    col_summary = pd.DataFrame({
        "Column": df.columns,
        "Data Type": [str(df[c].dtype) for c in df.columns],
        "Missing": [int(df[c].isna().sum()) for c in df.columns],
        "Missing %": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "Unique": [int(df[c].nunique(dropna=True)) for c in df.columns],
        "Example": [df[c].dropna().iloc[0] if df[c].dropna().shape[0] else "NA" for c in df.columns],
    })
    story.append(Paragraph("Column-level structure, missingness, uniqueness, and example values from the active dataset.", styles["BodyZN"]))
    story.append(pdf_table(col_summary, styles["SmallZN"], max_rows=30, max_cols=6))
    story.append(Spacer(1, 0.12 * inch))
    story.append(Paragraph("Dataset preview", styles["SubSectionZN"]))
    story.append(pdf_table(df.head(12), styles["SmallZN"], max_rows=12, max_cols=7))

    section_header(story, "3. Data Quality & Cleaning Output", styles)
    miss = pd.DataFrame({"Column": df.columns, "Missing Values": df.isna().sum().values, "Missing %": (df.isna().mean().values * 100).round(2)}).sort_values("Missing %", ascending=False)
    story.append(pdf_table(miss, styles["SmallZN"], max_rows=30, max_cols=3, col_widths=[3.1 * inch, 1.4 * inch, 1.4 * inch]))
    if nums:
        outlier_rows = []
        for c in nums:
            x = clean_numeric(df[c])
            if len(x) < 4:
                continue
            q1, q3 = x.quantile(0.25), x.quantile(0.75)
            iqr = q3 - q1
            low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            outlier_rows.append({"Variable": c, "IQR": format_num(iqr), "Lower fence": format_num(low), "Upper fence": format_num(high), "Outliers": int(((x < low) | (x > high)).sum())})
        if outlier_rows:
            story.append(Paragraph("IQR outlier scan", styles["SubSectionZN"]))
            story.append(pdf_table(pd.DataFrame(outlier_rows), styles["SmallZN"], max_rows=25, max_cols=5))

    section_header(story, "4. Descriptive Analytics Output", styles)
    if nums:
        desc_rows = []
        for c in nums:
            x = clean_numeric(df[c])
            if len(x) == 0:
                continue
            mode_val = x.mode().iloc[0] if not x.mode().empty else np.nan
            desc_rows.append({"Variable": c, "Count": len(x), "Mean": format_num(x.mean()), "Median": format_num(x.median()), "Mode": format_num(mode_val), "Std Dev": format_num(x.std(ddof=1)), "Variance": format_num(x.var(ddof=1)), "Min": format_num(x.min()), "Max": format_num(x.max()), "IQR": format_num(x.quantile(0.75) - x.quantile(0.25)), "Skewness": format_num(stats.skew(x, bias=False) if len(x) > 2 else np.nan), "Kurtosis": format_num(stats.kurtosis(x, bias=False) if len(x) > 3 else np.nan)})
        story.append(Paragraph("Numerical summary statistics", styles["SubSectionZN"]))
        story.append(pdf_table(pd.DataFrame(desc_rows), styles["SmallZN"], max_rows=25, max_cols=8))
    if cats:
        cat_rows = []
        for c in cats:
            vc = df[c].dropna().astype(str).value_counts()
            cat_rows.append({"Variable": c, "Unique values": int(df[c].nunique(dropna=True)), "Most frequent value": vc.index[0] if len(vc) else "NA", "Frequency": int(vc.iloc[0]) if len(vc) else 0})
        story.append(Paragraph("Categorical summary statistics", styles["SubSectionZN"]))
        story.append(pdf_table(pd.DataFrame(cat_rows), styles["SmallZN"], max_rows=25, max_cols=4))

    section_header(story, "5. Normality Testing Output", styles)
    norm_tbl = normality_summary_table(df)
    if not norm_tbl.empty:
        story.append(Paragraph("Shapiro-Wilk and Kolmogorov-Smirnov use p-values. Anderson-Darling is interpreted by comparing its statistic to the 5% critical value.", styles["CalloutZN"]))
        story.append(pdf_table(norm_tbl, styles["SmallZN"], max_rows=30, max_cols=6))
    else:
        story.append(Paragraph("No numeric variables with enough observations were available for normality testing.", styles["BodyZN"]))

    section_header(story, "6. Distribution Lab Output", styles)
    fit_tbl = distribution_fit_summary_table(df)
    if not fit_tbl.empty:
        story.append(Paragraph("Normal, Uniform, and Exponential fits were compared using mean squared error (MSE). The lowest MSE is highlighted as the best fit for that variable.", styles["CalloutZN"]))
        story.append(pdf_table(fit_tbl, styles["SmallZN"], max_rows=30, max_cols=6))
    else:
        story.append(Paragraph("No numeric variables with enough observations were available for distribution fitting.", styles["BodyZN"]))

    section_header(story, "7. Central Limit Theorem Output", styles)
    if nums:
        clt_settings = st.session_state.get("clt_settings", {})
        clt_col = clt_settings.get("Column", nums[0]) if clt_settings.get("Column", nums[0]) in nums else nums[0]
        clt_n = int(clt_settings.get("Sample size", 30))
        clt_sims = int(clt_settings.get("Simulations", 1000))
        sim = run_clt_simulation(df[clt_col], clt_n, clt_sims, seed=42)
        if sim is not None:
            clt_tbl = pd.DataFrame({
                "Metric": ["Selected variable", "Sample size per draw", "Number of simulations", "Original mean", "Mean of sample means", "Original standard deviation", "Standard deviation of sample means", "Theoretical standard error"],
                "Value": [clt_col, sim["sample_size"], sim["n_simulations"], format_num(sim["original_mean"]), format_num(sim["sampling_mean"]), format_num(sim["original_std"]), format_num(sim["sampling_std"]), format_num(sim["theoretical_se"])]
            })
            story.append(Paragraph("The Central Limit Theorem states that the sampling distribution of the mean becomes approximately normal as sample size increases, even when the original variable is not perfectly normal. The simulation below repeatedly samples from the selected numeric column and plots the distribution of those sample means.", styles["CalloutZN"]))
            story.append(pdf_table(clt_tbl, styles["SmallZN"], max_rows=10, max_cols=2, col_widths=[3.2 * inch, 2.2 * inch]))
            story.append(Paragraph("Figure 4. Central Limit Theorem Simulation", styles["SubSectionZN"]))
            story.append(Paragraph("The upper graph shows the original variable distribution. The lower graph shows the simulated sampling distribution of sample means with a fitted normal curve. A narrower, more bell-shaped sampling distribution supports the CLT concept.", styles["SmallZN"]))
            buf = clt_plot_buffer(df[clt_col], clt_col, clt_n, clt_sims, seed=42)
            if buf is not None:
                story.append(Image(buf, width=6.85 * inch, height=6.05 * inch))
        else:
            story.append(Paragraph("The selected numeric variable did not contain enough valid observations for a CLT simulation.", styles["BodyZN"]))
    else:
        story.append(Paragraph("No numeric variables were available for Central Limit Theorem simulation.", styles["BodyZN"]))

    story.append(PageBreak())
    section_header(story, "8. Graphical Outputs", styles)
    if nums:
        first = nums[0]
        data = clean_numeric(df[first])
        story.append(Paragraph(
            "This section contains report-ready graphical summaries. Each figure is labelled and briefly explained so the exported report is understandable without opening the app.",
            styles["CalloutZN"]
        ))
        if len(data) > 2:
            story.append(Paragraph(f"Figure 5. Histogram with Normal Fit — {first}", styles["SubSectionZN"]))
            story.append(Paragraph(
                "This plot compares the observed distribution of the selected numerical variable with a fitted normal curve. It supports visual inspection of shape, spread, skewness, and approximate normality.",
                styles["SmallZN"]
            ))
            fig, ax = plt.subplots(figsize=(7.0, 3.8))
            ax.hist(data, bins=min(30, max(8, int(np.sqrt(len(data))))), density=True, alpha=0.65, label="Observed data")
            xs = np.linspace(data.min(), data.max(), 300)
            if data.std(ddof=1) > 0:
                ax.plot(xs, stats.norm.pdf(xs, data.mean(), data.std(ddof=1)), linewidth=2, label="Normal fit")
            ax.set_title(f"Histogram with Normal Fit: {first}")
            ax.set_xlabel(first)
            ax.set_ylabel("Density")
            ax.legend(fontsize=8)
            ax.grid(alpha=0.25)
            story.append(Image(matplotlib_image_buffer(fig), width=6.85 * inch, height=3.65 * inch))
            story.append(Spacer(1, 0.12 * inch))

            story.append(Paragraph(f"Figure 6. Q-Q Plot for Normality — {first}", styles["SubSectionZN"]))
            story.append(Paragraph(
                "The Q-Q plot compares sample quantiles against theoretical normal quantiles. Points close to the reference line suggest approximate normality; strong curves or extreme departures suggest non-normality.",
                styles["SmallZN"]
            ))
            fig = plt.figure(figsize=(6.2, 4.0))
            ax = fig.add_subplot(111)
            stats.probplot(data, dist="norm", plot=ax)
            ax.set_title(f"Q-Q Plot: {first}")
            ax.grid(alpha=0.25)
            story.append(Image(matplotlib_image_buffer(fig), width=6.25 * inch, height=4.0 * inch))
            story.append(Spacer(1, 0.12 * inch))

            if len(data) >= 5 and data.nunique() > 1:
                story.append(Paragraph(f"Figure 7. Distribution Fit Comparison — {first}", styles["SubSectionZN"]))
                story.append(Paragraph(
                    "This graph overlays Normal, Uniform, and Exponential fitted curves on the observed histogram. The Distribution Lab table ranks these fits using MSE; the lowest MSE is treated as the best visual fit among the tested options.",
                    styles["SmallZN"]
                ))
                story.append(Image(best_fit_plot_buffer(data, first), width=6.85 * inch, height=3.85 * inch))
                story.append(Spacer(1, 0.12 * inch))

        if len(nums) >= 2:
            story.append(Paragraph("Figure 8. Correlation Heatmap — Numerical Variables", styles["SubSectionZN"]))
            story.append(Paragraph(
                "This grid is a correlation heatmap, not a random chart. Each cell shows the Pearson correlation coefficient between two numerical variables. Values near +1 indicate strong positive association, values near -1 indicate strong negative association, and values near 0 indicate weak linear association.",
                styles["SmallZN"]
            ))
            corr = df[nums].corr(numeric_only=True)
            fig, ax = plt.subplots(figsize=(6.5, 4.6))
            im = ax.imshow(corr, aspect="auto", cmap="RdPu", vmin=-1, vmax=1)
            ax.set_xticks(range(len(corr.columns)))
            ax.set_xticklabels(corr.columns, rotation=45, ha="right", fontsize=7)
            ax.set_yticks(range(len(corr.index)))
            ax.set_yticklabels(corr.index, fontsize=7)
            ax.set_title("Correlation Heatmap")
            for i in range(len(corr.index)):
                for j in range(len(corr.columns)):
                    ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", fontsize=6)
            cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            cbar.set_label("Correlation coefficient", fontsize=7)
            story.append(Image(matplotlib_image_buffer(fig), width=6.6 * inch, height=4.6 * inch))
    else:
        story.append(Paragraph("No numeric variables were available for graphical statistical summaries.", styles["BodyZN"]))
    story.append(PageBreak())
    section_header(story, "9. Statistical Inference Output", styles)
    if st.session_state.get("results"):
        res = pd.DataFrame(st.session_state.results)
        story.append(Paragraph("The following outputs were stored from statistical tests run inside the toolkit during the current session.", styles["CalloutZN"]))
        story.append(pdf_table(res, styles["SmallZN"], max_rows=35, max_cols=4, col_widths=[1.55 * inch, 1.15 * inch, 0.85 * inch, 3.7 * inch]))
    else:
        story.append(Paragraph("No hypothesis-test outputs have been stored yet. Run tests in the Statistical Inference module before exporting to include test statistics, p-values, decisions, and interpretations.", styles["CalloutZN"]))

    section_header(story, "10. Word Cloud Lab Output", styles)
    if st.session_state.get("wordcloud_freq") is not None:
        wc_freq = st.session_state.wordcloud_freq.copy()
        story.append(Paragraph("Custom weighted word frequencies from the Word Cloud Lab. The word cloud is generated from all stored weighted words, while the table shows the highest-frequency terms for readability.", styles["BodyZN"]))
        story.append(pdf_table(wc_freq.head(60), styles["SmallZN"], max_rows=60, max_cols=2, col_widths=[3.4 * inch, 2.1 * inch]))
        if WORDCLOUD_AVAILABLE:
            try:
                frequencies = dict(zip(wc_freq["Word"].astype(str), wc_freq["Weighted Frequency"].astype(float)))
                story.append(Paragraph("Figure 9. Complete Custom Weighted Word Cloud", styles["SubSectionZN"]))
                story.append(Paragraph("The largest words came from the high-weight input box, medium-sized words from the medium-weight box, and smaller supporting words from the low-weight box.", styles["SmallZN"]))
                story.append(Image(wordcloud_image_buffer(frequencies), width=6.85 * inch, height=3.45 * inch))
            except Exception:
                story.append(Paragraph("The word cloud image could not be embedded, but the weighted frequency table is included above.", styles["BodyZN"]))
    else:
        story.append(Paragraph("No word cloud output has been generated in the current session. Use the Word Cloud Lab first if you want custom text analytics included.", styles["BodyZN"]))

    section_header(story, "11. Interpretation Notes", styles)
    story.append(Paragraph(
        "Statistical significance should be interpreted together with assumptions, study design, variable quality, sample size, and domain context. "
        "MSE-based distribution fitting is useful for comparing curve closeness visually, while formal goodness-of-fit tests and subject-matter reasoning should also be considered. "
        "The report is designed as an analytical summary, not as a substitute for professional judgment.", styles["CalloutZN"]
    ))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()

# ----------------------------- Navigation -----------------------------
if "df" not in st.session_state:
    st.session_state.df = None
if "original_df" not in st.session_state:
    st.session_state.original_df = None
if "results" not in st.session_state:
    st.session_state.results = []

pages = [
    "Overview", "Data Workspace", "Data Quality & Cleaning", "Descriptive Analytics", "Visual Analytics",
    "Distribution Lab", "Normality Testing", "Statistical Inference", "Test Advisor", "Word Cloud Lab",
    "Report & Export", "User Guide"
]

st.sidebar.markdown("""
<div class='sidebar-brand'>
    <div class='brand-title'>ZN Analytics</div>
    <div class='brand-subtitle'>Premium data analysis suite</div>
</div>
""", unsafe_allow_html=True)

icons = {
    "Overview": "✦", "Data Workspace": "▣", "Data Quality & Cleaning": "✓",
    "Descriptive Analytics": "Σ", "Visual Analytics": "◈", "Distribution Lab": "⌁",
    "Normality Testing": "≈", "Statistical Inference": "⚖", "Test Advisor": "?",
    "Word Cloud Lab": "☁", "Report & Export": "⇩", "User Guide": "i"
}
if "page" not in st.session_state:
    st.session_state.page = "Overview"
for p in pages:
    label = f"{icons.get(p, '•')}  {p}"
    if st.sidebar.button(label, key=f"nav_{p}"):
        st.session_state.page = p
page = st.session_state.page
st.sidebar.markdown(f"<div class='info-box'><b>Current module:</b><br>{page}</div>", unsafe_allow_html=True)

# ----------------------------- Pages -----------------------------
if page == "Overview":
    st.markdown(
        """
        <div class='hero'>
            <div class='hero-title'>ZN Analytics Toolkit</div>
            <div class='hero-subtitle'>From raw data to statistical insight.</div>
            <div class='hero-body'>
                A professional no-code analytics dashboard for data cleaning, exploration, visualization,
                distribution fitting, Central Limit Theorem simulation, statistical inference, test selection, and word cloud analytics.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    with c1: metric_card("Created by", "Naresh Punjabi")
    with c2: metric_card("Course", "Tools and Methods of Data Analysis")
    with c3: metric_card("University", "SRH University Leipzig")

    st.markdown("### Toolkit Modules")
    features = [
        ("Data Workspace", "Upload CSV/Excel files, load the sample dataset, inspect structure, and detect variable types."),
        ("Data Quality & Cleaning", "Analyze missing values, duplicates, outliers, and apply preprocessing actions."),
        ("Descriptive Analytics", "Generate summary statistics, categorical frequency tables, skewness, kurtosis, and IQR."),
        ("Visual Analytics", "Create interactive histograms, boxplots, scatter plots, line charts, bars, pies, and heatmaps."),
        ("Distribution Lab", "Fit Normal, Uniform, and Exponential distributions using MSE, and simulate the Central Limit Theorem."),
        ("Normality Testing", "Run Shapiro-Wilk, Kolmogorov-Smirnov, and Anderson-Darling tests with supporting plots."),
        ("Statistical Inference", "Run t-tests, Z-tests, ANOVA, two-way ANOVA, chi-square, Levene, correlation, and non-parametric tests."),
        ("Test Advisor", "Answer guided questions to choose the right statistical test and its alternatives."),
        ("Word Cloud Lab", "Create weighted word clouds from custom user input, independent of the dataset."),
    ]
    cols = st.columns(3)
    for i, (title, desc) in enumerate(features):
        with cols[i % 3]:
            st.markdown(f"<div class='feature-card'><b>{title}</b><p>{desc}</p></div>", unsafe_allow_html=True)
    st.markdown("<div class='info-box'><b>Workflow:</b> Upload Data → Clean Data → Explore Patterns → Fit Distributions → Simulate CLT → Run Tests → Export Insights</div>", unsafe_allow_html=True)

elif page == "Data Workspace":
    st.title("Data Workspace")
    st.write("Upload a dataset or load the built-in professional sample dataset.")
    c1, c2 = st.columns([2, 1])
    with c1:
        uploaded = st.file_uploader("Upload CSV or Excel file", type=["csv", "xlsx"])
    with c2:
        st.write("")
        st.write("")
        if st.button("Load sample employee dataset"):
            st.session_state.df = load_sample()
            st.session_state.original_df = st.session_state.df.copy()
            st.success("Sample dataset loaded.")
    if uploaded is not None:
        if uploaded.name.lower().endswith(".csv"):
            df = pd.read_csv(uploaded)
        else:
            df = pd.read_excel(uploaded)
        st.session_state.df = df
        st.session_state.original_df = df.copy()
        st.success("Dataset uploaded successfully.")

    df = get_df()
    if df is not None:
        total_cells = df.shape[0] * df.shape[1]
        missing_cells = int(df.isna().sum().sum())
        dupes = int(df.duplicated().sum())
        c1, c2, c3, c4, c5 = st.columns(5)
        with c1: metric_card("Rows", df.shape[0])
        with c2: metric_card("Columns", df.shape[1])
        with c3: metric_card("Missing Cells", missing_cells)
        with c4: metric_card("Duplicate Rows", dupes)
        with c5: metric_card("Memory", f"{df.memory_usage(deep=True).sum()/1024:.1f} KB")

        st.subheader("Dataset Preview")
        st.dataframe(df.head(20), use_container_width=True)

        summary = pd.DataFrame({
            "Column": df.columns,
            "Data Type": [str(df[c].dtype) for c in df.columns],
            "Missing Values": [int(df[c].isna().sum()) for c in df.columns],
            "Missing %": [round(float(df[c].isna().mean()*100), 2) for c in df.columns],
            "Unique Values": [int(df[c].nunique(dropna=True)) for c in df.columns],
            "Example Value": [df[c].dropna().iloc[0] if df[c].dropna().shape[0] else "NA" for c in df.columns],
        })
        st.subheader("Column Summary")
        st.dataframe(summary, use_container_width=True)

        st.markdown(f"<div class='info-box'><b>Detected:</b> {len(numeric_cols(df))} numeric columns, {len(categorical_cols(df))} categorical/text columns.</div>", unsafe_allow_html=True)

elif page == "Data Quality & Cleaning":
    st.title("Data Quality & Cleaning")
    df = require_df()
    if df is not None:
        st.subheader("Missing Value Analysis")
        miss = pd.DataFrame({
            "Column": df.columns,
            "Missing Values": df.isna().sum().values,
            "Missing %": (df.isna().mean().values * 100).round(2),
        }).sort_values("Missing %", ascending=False)
        st.dataframe(miss, use_container_width=True)
        fig = px.bar(miss, x="Column", y="Missing %", title="Missing Values by Column")
        st.plotly_chart(style_fig(fig), use_container_width=True)

        st.subheader("Cleaning Actions")
        a, b, c = st.columns(3)
        with a:
            if st.button("Remove duplicate rows"):
                before = len(df)
                st.session_state.df = df.drop_duplicates().reset_index(drop=True)
                st.success(f"Removed {before-len(st.session_state.df)} duplicate rows.")
        with b:
            if st.button("Drop rows with missing values"):
                before = len(df)
                st.session_state.df = df.dropna().reset_index(drop=True)
                st.success(f"Removed {before-len(st.session_state.df)} rows containing missing values.")
        with c:
            if st.button("Reset to original dataset"):
                if st.session_state.original_df is not None:
                    st.session_state.df = st.session_state.original_df.copy()
                    st.success("Dataset reset.")

        st.markdown("#### Fill Missing Values")
        target_col = st.selectbox("Column to fill", df.columns)
        method = st.selectbox("Fill method", ["Mean (numeric)", "Median (numeric)", "Mode", "Custom value"])
        custom = st.text_input("Custom fill value", value="") if method == "Custom value" else None
        if st.button("Apply fill"):
            new_df = df.copy()
            if method.startswith("Mean"):
                new_df[target_col] = new_df[target_col].fillna(pd.to_numeric(new_df[target_col], errors="coerce").mean())
            elif method.startswith("Median"):
                new_df[target_col] = new_df[target_col].fillna(pd.to_numeric(new_df[target_col], errors="coerce").median())
            elif method == "Mode":
                mode = new_df[target_col].mode(dropna=True)
                if not mode.empty:
                    new_df[target_col] = new_df[target_col].fillna(mode.iloc[0])
            else:
                new_df[target_col] = new_df[target_col].fillna(custom)
            st.session_state.df = new_df
            st.success("Missing values filled.")

        st.markdown("#### Outlier Detection using IQR")
        nums = numeric_cols(df)
        if nums:
            oc = st.selectbox("Numeric column for outlier detection", nums)
            x = clean_numeric(df[oc])
            q1, q3 = x.quantile(0.25), x.quantile(0.75)
            iqr = q3 - q1
            lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
            outlier_count = int(((x < lower) | (x > upper)).sum())
            st.write(f"IQR bounds: [{format_num(lower)}, {format_num(upper)}]. Detected outliers: **{outlier_count}**")
            fig = px.box(df, y=oc, title=f"Outlier Inspection: {oc}")
            st.plotly_chart(style_fig(fig), use_container_width=True)

elif page == "Descriptive Analytics":
    st.title("Descriptive Analytics")
    df = require_df()
    if df is not None:
        nums = numeric_cols(df)
        cats = categorical_cols(df)
        st.subheader("Numerical Summary")
        if nums:
            rows=[]
            for c in nums:
                x=clean_numeric(df[c])
                rows.append({
                    "Column": c, "Count": len(x), "Mean": x.mean(), "Median": x.median(), "Mode": x.mode().iloc[0] if not x.mode().empty else np.nan,
                    "Std Dev": x.std(ddof=1), "Variance": x.var(ddof=1), "Min": x.min(), "Max": x.max(), "Range": x.max()-x.min(),
                    "Q1": x.quantile(.25), "Q3": x.quantile(.75), "IQR": x.quantile(.75)-x.quantile(.25),
                    "Skewness": x.skew(), "Kurtosis": x.kurtosis(), "Missing": df[c].isna().sum()
                })
            desc=pd.DataFrame(rows)
            st.dataframe(desc.round(3), use_container_width=True)
            st.markdown("<div class='info-box'>Skewness near 0 suggests approximate symmetry. Large IQR or standard deviation suggests greater spread. Kurtosis describes tail heaviness compared with a normal distribution.</div>", unsafe_allow_html=True)
        else:
            st.info("No numeric columns detected.")

        st.subheader("Categorical Summary")
        if cats:
            cat_col=st.selectbox("Choose categorical column", cats)
            freq=df[cat_col].value_counts(dropna=False).reset_index()
            freq.columns=[cat_col,"Frequency"]
            freq["Percentage"]=(freq["Frequency"]/len(df)*100).round(2)
            st.dataframe(freq, use_container_width=True)
            fig=px.bar(freq, x=cat_col, y="Frequency", title=f"Frequency Distribution: {cat_col}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        else:
            st.info("No categorical columns detected.")

elif page == "Visual Analytics":
    st.title("Visual Analytics")
    df = require_df()
    if df is not None:
        nums, cats = numeric_cols(df), categorical_cols(df)
        chart = st.selectbox("Choose chart type", ["Histogram", "Boxplot", "Scatter Plot", "Line Chart", "Bar Chart", "Pie Chart", "Correlation Heatmap", "Scatter Matrix"])
        if chart == "Histogram" and nums:
            x=st.selectbox("Numeric column", nums)
            color=st.selectbox("Optional group/color", ["None"]+cats)
            fig=px.histogram(df, x=x, color=None if color=="None" else color, nbins=30, title=f"Histogram of {x}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Boxplot" and nums:
            y=st.selectbox("Numeric column", nums)
            group=st.selectbox("Optional grouping column", ["None"]+cats)
            fig=px.box(df, y=y, x=None if group=="None" else group, points="outliers", title=f"Boxplot of {y}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Scatter Plot" and len(nums)>=2:
            x=st.selectbox("X-axis", nums)
            y=st.selectbox("Y-axis", [c for c in nums if c!=x] or nums)
            color=st.selectbox("Optional color", ["None"]+cats)
            fig=px.scatter(df, x=x, y=y, color=None if color=="None" else color, trendline="ols", title=f"{x} vs {y}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Line Chart" and nums:
            y=st.selectbox("Y-axis", nums)
            x=st.selectbox("X-axis", df.columns.tolist())
            fig=px.line(df, x=x, y=y, title=f"Line Chart: {y} by {x}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Bar Chart" and cats:
            c=st.selectbox("Categorical column", cats)
            counts=df[c].value_counts().reset_index(); counts.columns=[c,"Count"]
            fig=px.bar(counts, x=c, y="Count", title=f"Bar Chart: {c}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Pie Chart" and cats:
            c=st.selectbox("Categorical column", cats)
            counts=df[c].value_counts().reset_index(); counts.columns=[c,"Count"]
            fig=px.pie(counts, names=c, values="Count", title=f"Pie Chart: {c}")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Correlation Heatmap" and len(nums)>=2:
            corr=df[nums].corr(numeric_only=True).round(3)
            fig=px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r", title="Correlation Heatmap")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        elif chart == "Scatter Matrix" and len(nums)>=2:
            selected=st.multiselect("Choose numeric columns", nums, default=nums[:min(4,len(nums))])
            if len(selected)>=2:
                fig=px.scatter_matrix(df, dimensions=selected, title="Pairwise Scatter Matrix")
                st.plotly_chart(style_fig(fig), use_container_width=True)
        else:
            st.info("This chart needs compatible column types.")

elif page == "Distribution Lab":
    st.title("Distribution Lab")
    df = require_df()
    if df is not None:
        nums=numeric_cols(df)
        if nums:
            st.subheader("Theoretical Distributions")
            dist=st.selectbox("Distribution", ["Normal", "Binomial", "Poisson", "Exponential"])
            if dist == "Normal":
                mu=st.number_input("Mean", value=0.0); sd=st.number_input("Standard deviation", value=1.0, min_value=0.001)
                x=np.linspace(mu-4*sd, mu+4*sd, 300)
                d=pd.DataFrame({"x":x,"PDF":stats.norm.pdf(x,mu,sd),"CDF":stats.norm.cdf(x,mu,sd)})
                st.plotly_chart(style_fig(px.line(d,x="x",y=["PDF","CDF"],title="Normal PDF and CDF")), use_container_width=True)
            elif dist == "Binomial":
                n=st.number_input("Trials n", min_value=1, value=20); p=st.number_input("Success probability p", min_value=0.0, max_value=1.0, value=0.5)
                x=np.arange(0,n+1); d=pd.DataFrame({"x":x,"PMF":stats.binom.pmf(x,n,p),"CDF":stats.binom.cdf(x,n,p)})
                st.plotly_chart(style_fig(px.bar(d,x="x",y="PMF",title="Binomial PMF")), use_container_width=True)
                st.plotly_chart(style_fig(px.line(d,x="x",y="CDF",title="Binomial CDF")), use_container_width=True)
            elif dist == "Poisson":
                lam=st.number_input("Lambda λ", min_value=0.001, value=4.0)
                x=np.arange(0, max(20,int(lam*4)+1)); d=pd.DataFrame({"x":x,"PMF":stats.poisson.pmf(x,lam),"CDF":stats.poisson.cdf(x,lam)})
                st.plotly_chart(style_fig(px.bar(d,x="x",y="PMF",title="Poisson PMF")), use_container_width=True)
                st.plotly_chart(style_fig(px.line(d,x="x",y="CDF",title="Poisson CDF")), use_container_width=True)
            else:
                lam=st.number_input("Rate λ", min_value=0.001, value=1.0)
                x=np.linspace(0, 8/lam, 300); d=pd.DataFrame({"x":x,"PDF":stats.expon.pdf(x,scale=1/lam),"CDF":stats.expon.cdf(x,scale=1/lam)})
                st.plotly_chart(style_fig(px.line(d,x="x",y=["PDF","CDF"],title="Exponential PDF and CDF")), use_container_width=True)

            st.subheader("Distribution Fitting using MSE")
            col=st.selectbox("Select numeric column for fitting", nums)
            data=clean_numeric(df[col])
            bins=st.slider("Histogram bins", 10, 80, 30)
            hist, edges=np.histogram(data, bins=bins, density=True)
            centers=(edges[:-1]+edges[1:])/2
            fits={}
            # Normal
            mu, sd=data.mean(), data.std(ddof=1)
            fits["Normal"] = stats.norm.pdf(centers, mu, sd)
            # Uniform
            lo, hi=data.min(), data.max()
            fits["Uniform"] = stats.uniform.pdf(centers, loc=lo, scale=max(hi-lo, 1e-9))
            # Exponential
            loc, scale = stats.expon.fit(data)
            fits["Exponential"] = stats.expon.pdf(centers, loc=loc, scale=scale)
            mse={k: float(np.mean((hist-v)**2)) for k,v in fits.items()}
            best=min(mse, key=mse.get)
            comp=pd.DataFrame({"Distribution":list(mse.keys()), "MSE":list(mse.values())}).sort_values("MSE")
            st.dataframe(comp.round(6), use_container_width=True)
            st.success(f"Best fit by lowest MSE: {best}")
            fig=go.Figure()
            fig.add_trace(go.Bar(x=centers, y=hist, name="Observed histogram density", opacity=0.55))
            x_line=np.linspace(data.min(), data.max(), 400)
            fig.add_trace(go.Scatter(x=x_line, y=stats.norm.pdf(x_line, mu, sd), mode="lines", name=f"Normal MSE={mse['Normal']:.5f}", line=dict(color=ACCENT, width=4 if best=='Normal' else 2)))
            fig.add_trace(go.Scatter(x=x_line, y=stats.uniform.pdf(x_line, loc=lo, scale=max(hi-lo,1e-9)), mode="lines", name=f"Uniform MSE={mse['Uniform']:.5f}", line=dict(width=4 if best=='Uniform' else 2)))
            fig.add_trace(go.Scatter(x=x_line, y=stats.expon.pdf(x_line, loc=loc, scale=scale), mode="lines", name=f"Exponential MSE={mse['Exponential']:.5f}", line=dict(width=4 if best=='Exponential' else 2)))
            fig.update_layout(xaxis_title=col, yaxis_title="Density")
            st.plotly_chart(style_fig(fig, f"Distribution Fitting: {col}"), use_container_width=True)
            st.markdown("<div class='info-box'>MSE compares fitted density values with the observed histogram density. The lowest MSE indicates the closest curve among the tested distributions, but it should be interpreted together with diagnostic plots and formal tests.</div>", unsafe_allow_html=True)

            st.divider()
            st.subheader("Central Limit Theorem Simulator")
            st.markdown("<div class='info-box'>The Central Limit Theorem says that when we repeatedly take samples and calculate their means, the distribution of those means becomes approximately normal as sample size increases. This simulation lets users see that idea using the active dataset.</div>", unsafe_allow_html=True)
            clt_col = st.selectbox("Select numeric column for CLT simulation", nums, key="clt_col_select")
            cc1, cc2, cc3 = st.columns(3)
            with cc1:
                sample_size = st.slider("Sample size per draw", min_value=2, max_value=min(200, max(2, len(clean_numeric(df[clt_col])))), value=min(30, max(2, len(clean_numeric(df[clt_col])))), step=1)
            with cc2:
                n_simulations = st.select_slider("Number of simulations", options=[100, 250, 500, 1000, 2000, 5000], value=1000)
            with cc3:
                seed = st.number_input("Random seed", min_value=0, max_value=99999, value=42, step=1)
            clt_data = clean_numeric(df[clt_col])
            sim = run_clt_simulation(clt_data, sample_size, n_simulations, seed=int(seed))
            if sim is not None:
                st.session_state.clt_settings = {"Column": clt_col, "Sample size": sample_size, "Simulations": n_simulations}
                m1, m2, m3, m4 = st.columns(4)
                with m1: metric_card("Original mean", format_num(sim["original_mean"]))
                with m2: metric_card("Mean of sample means", format_num(sim["sampling_mean"]))
                with m3: metric_card("Sampling std. dev.", format_num(sim["sampling_std"]))
                with m4: metric_card("Theoretical SE", format_num(sim["theoretical_se"]))
                clt_table = pd.DataFrame({
                    "Metric": ["Original mean", "Mean of sample means", "Original standard deviation", "Standard deviation of sample means", "Theoretical standard error"],
                    "Value": [format_num(sim["original_mean"]), format_num(sim["sampling_mean"]), format_num(sim["original_std"]), format_num(sim["sampling_std"]), format_num(sim["theoretical_se"])]
                })
                st.dataframe(clt_table, use_container_width=True)
                fig_original, fig_sampling, fig_qq = clt_plotly_figs(clt_data, clt_col, sample_size, n_simulations, seed=int(seed))
                st.plotly_chart(fig_original, use_container_width=True)
                st.plotly_chart(fig_sampling, use_container_width=True)
                if fig_qq is not None:
                    st.plotly_chart(fig_qq, use_container_width=True)
                st.success("Interpretation: Compare the original distribution with the sampling distribution. Even if the original data is skewed or irregular, the sample means should become more bell-shaped as the sample size increases. The standard deviation of the sample means should also move close to the theoretical standard error.")
            else:
                st.warning("This column does not have enough valid numeric values for a CLT simulation.")

elif page == "Normality Testing":
    st.title("Normality Testing")
    df=require_df()
    if df is not None:
        nums=numeric_cols(df)
        if nums:
            col=st.selectbox("Numeric column", nums)
            alpha=st.selectbox("Alpha level", [0.01,0.05,0.10], index=1)
            data=clean_numeric(df[col])
            if len(data) < 8:
                st.warning("Normality tests require more observations for reliable results.")
            else:
                rows=[]
                # Shapiro
                sh_stat, sh_p=stats.shapiro(data.sample(min(len(data),5000), random_state=1) if len(data)>5000 else data)
                rows.append({"Test":"Shapiro-Wilk","Statistic":sh_stat,"p-value":sh_p,"Decision":"Reject normality" if sh_p<alpha else "Fail to reject normality"})
                # KS with estimated mean/std
                mu, sd=data.mean(), data.std(ddof=1)
                ks_stat, ks_p=stats.kstest(data, 'norm', args=(mu, sd))
                rows.append({"Test":"Kolmogorov-Smirnov","Statistic":ks_stat,"p-value":ks_p,"Decision":"Reject normality" if ks_p<alpha else "Fail to reject normality"})
                # Anderson
                ad=stats.anderson(data, dist='norm')
                # critical value nearest 5%
                sig_levels=list(ad.significance_level)
                crits=list(ad.critical_values)
                idx=min(range(len(sig_levels)), key=lambda i: abs(sig_levels[i]-alpha*100))
                ad_decision="Reject normality" if ad.statistic > crits[idx] else "Fail to reject normality"
                rows.append({"Test":"Anderson-Darling","Statistic":ad.statistic,"p-value":"Uses critical values","Decision":ad_decision})
                st.dataframe(pd.DataFrame(rows), use_container_width=True)
                st.markdown(f"<div class='info-box'><b>Interpretation:</b> For Shapiro-Wilk and Kolmogorov-Smirnov, p < α suggests the data significantly differs from a normal distribution. Anderson-Darling compares the statistic to critical values; if the statistic is larger than the critical value, normality is rejected.</div>", unsafe_allow_html=True)
                st.subheader("Histogram with Normal Fit")
                st.plotly_chart(hist_with_normal(data, col), use_container_width=True)
                st.subheader("Q-Q Plot")
                fig=qq_plot(data, f"Q-Q Plot: {col}")
                if fig: st.plotly_chart(fig, use_container_width=True)
                fig=px.box(df, y=col, title=f"Boxplot: {col}")
                st.plotly_chart(style_fig(fig), use_container_width=True)

elif page == "Statistical Inference":
    st.title("Statistical Inference")
    df=require_df()
    if df is not None:
        nums, cats = numeric_cols(df), categorical_cols(df)
        test=st.selectbox("Choose statistical test", [
            "Confidence Interval for Mean", "One-sample t-test", "Independent two-sample t-test", "Paired t-test",
            "Z-test", "One-way ANOVA", "Two-way ANOVA", "Levene's Test", "Chi-square Goodness-of-Fit",
            "Chi-square Independence", "Pearson Correlation", "Mann-Whitney U", "Wilcoxon Signed-Rank", "Kruskal-Wallis"
        ])
        alpha=st.selectbox("Alpha level", [0.01,0.05,0.10], index=1)
        try:
            if test == "Confidence Interval for Mean" and nums:
                col=st.selectbox("Numeric column", nums); conf=st.selectbox("Confidence level", [0.90,0.95,0.99], index=1)
                x=clean_numeric(df[col]); mean=x.mean(); sem=stats.sem(x); margin=stats.t.ppf((1+conf)/2, len(x)-1)*sem
                lo,hi=mean-margin,mean+margin
                st.metric("Sample Mean", format_num(mean)); st.write(f"{int(conf*100)}% confidence interval: **[{format_num(lo)}, {format_num(hi)}]**")
                st.markdown(f"<div class='info-box'>We are {int(conf*100)}% confident that the true population mean of {col} lies between {format_num(lo)} and {format_num(hi)}.</div>", unsafe_allow_html=True)
                fig=hist_with_normal(x,col); fig.add_vline(x=lo, line_dash="dash", annotation_text="Lower CI"); fig.add_vline(x=hi, line_dash="dash", annotation_text="Upper CI")
                st.plotly_chart(fig,use_container_width=True)
            elif test == "One-sample t-test" and nums:
                col=st.selectbox("Numeric column", nums); mu0=st.number_input("Hypothesized mean", value=0.0)
                x=clean_numeric(df[col]); stat,p=stats.ttest_1samp(x, mu0)
                st.write(f"t-statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha)
                st.markdown(f"<div class='info-box'>{interp}</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                fig=hist_with_normal(x,col); fig.add_vline(x=mu0, line_color=ACCENT_STRONG, line_dash="dash", annotation_text="H₀ mean")
                st.plotly_chart(fig,use_container_width=True)
            elif test == "Independent two-sample t-test" and nums and cats:
                y=st.selectbox("Numeric outcome", nums); g=st.selectbox("Grouping column with two groups", cats)
                groups=df[g].dropna().unique().tolist(); selected=st.multiselect("Select exactly two groups", groups, default=groups[:2])
                if len(selected)==2:
                    x1=clean_numeric(df[df[g]==selected[0]][y]); x2=clean_numeric(df[df[g]==selected[1]][y]); stat,p=stats.ttest_ind(x1,x2,equal_var=False)
                    st.write(f"t-statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha)
                    st.markdown(f"<div class='info-box'>{interp} Welch's version is used by default because it does not assume equal variances.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                    fig=px.box(df[df[g].isin(selected)], x=g, y=y, points="all", title=f"{y} by {g}"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Paired t-test" and len(nums)>=2:
                a=st.selectbox("First numeric column", nums); b=st.selectbox("Second numeric column", [c for c in nums if c!=a])
                pair=df[[a,b]].dropna(); stat,p=stats.ttest_rel(pair[a],pair[b])
                st.write(f"t-statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha)
                st.markdown(f"<div class='info-box'>{interp}</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                differences = pair[a] - pair[b]
                st.markdown("<div class='info-box'><b>Graphical output:</b> For a paired t-test, the key assumption is that the paired differences are approximately normal. The Q-Q plot below checks the distribution of those differences.</div>", unsafe_allow_html=True)
                fig=qq_plot(differences, f"Q-Q Plot of Paired Differences: {a} - {b}")
                if fig: st.plotly_chart(fig, use_container_width=True)
            elif test == "Z-test" and nums:
                ztype=st.radio("Z-test type", ["One-sample Z-test", "Two-sample Z-test"])
                if ztype == "One-sample Z-test":
                    col=st.selectbox("Numeric column", nums); mu0=st.number_input("Hypothesized mean", value=0.0); sigma=st.number_input("Known population standard deviation σ", min_value=0.0001, value=10.0)
                    x=clean_numeric(df[col]); z=(x.mean()-mu0)/(sigma/sqrt(len(x))); p=2*(1-stats.norm.cdf(abs(z)))
                    st.write(f"z-statistic: **{format_num(z)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp} Z-tests require a known population standard deviation or a large-sample approximation.</div>", unsafe_allow_html=True); add_result(test,z,p,interp)
                    xs=np.linspace(-4,4,300); fig=px.line(x=xs,y=stats.norm.pdf(xs),title="Standard Normal Curve for Z-test"); fig.add_vline(x=z,line_color=ACCENT,line_dash="dash",annotation_text="Observed z"); st.plotly_chart(style_fig(fig),use_container_width=True)
                else:
                    y=st.selectbox("Numeric outcome", nums); g=st.selectbox("Two-group column", cats); groups=df[g].dropna().unique().tolist(); selected=st.multiselect("Select exactly two groups", groups, default=groups[:2])
                    s1=st.number_input("Known σ for group 1", min_value=0.0001, value=10.0); s2=st.number_input("Known σ for group 2", min_value=0.0001, value=10.0)
                    if len(selected)==2:
                        x1=clean_numeric(df[df[g]==selected[0]][y]); x2=clean_numeric(df[df[g]==selected[1]][y]); z=(x1.mean()-x2.mean())/sqrt(s1**2/len(x1)+s2**2/len(x2)); p=2*(1-stats.norm.cdf(abs(z)))
                        st.write(f"z-statistic: **{format_num(z)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp}</div>", unsafe_allow_html=True); add_result(test,z,p,interp)
                        fig=px.box(df[df[g].isin(selected)],x=g,y=y,title="Two-sample Z-test Group Comparison"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "One-way ANOVA" and nums and cats:
                y=st.selectbox("Numeric outcome", nums); g=st.selectbox("Factor/group column", cats)
                vals=[clean_numeric(df[df[g]==val][y]) for val in df[g].dropna().unique()]
                vals=[v for v in vals if len(v)>1]
                stat,p=stats.f_oneway(*vals)
                st.write(f"F-statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp} ANOVA tests whether at least one group mean differs.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                fig=px.box(df,x=g,y=y,points="all",title=f"One-way ANOVA: {y} by {g}"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Two-way ANOVA" and nums and len(cats)>=2:
                y=st.selectbox("Numeric outcome", nums); a=st.selectbox("Factor A", cats); b=st.selectbox("Factor B", [c for c in cats if c!=a])
                temp=df[[y,a,b]].dropna().copy(); formula=f'Q("{y}") ~ C(Q("{a}")) + C(Q("{b}")) + C(Q("{a}")):C(Q("{b}"))'
                model=ols(formula, data=temp).fit(); table=sm.stats.anova_lm(model, typ=2)
                st.dataframe(table.round(4), use_container_width=True)
                st.markdown("<div class='info-box'>Two-way ANOVA evaluates the main effect of each factor and the interaction effect between the two factors.</div>", unsafe_allow_html=True)
                means=temp.groupby([a,b], as_index=False)[y].mean()
                fig=px.line(means,x=a,y=y,color=b,markers=True,title=f"Interaction Plot: {a} × {b} on {y}"); st.plotly_chart(style_fig(fig),use_container_width=True)
                fig2=px.box(temp,x=a,y=y,color=b,title="Grouped Boxplot for Two-way ANOVA"); st.plotly_chart(style_fig(fig2),use_container_width=True)
            elif test == "Levene's Test" and nums and cats:
                y=st.selectbox("Numeric outcome", nums); g=st.selectbox("Group column", cats)
                vals=[clean_numeric(df[df[g]==val][y]) for val in df[g].dropna().unique()]; vals=[v for v in vals if len(v)>1]
                stat,p=stats.levene(*vals)
                st.write(f"Levene statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha,"equal variances"); st.markdown(f"<div class='info-box'>{interp} If significant, group variances are likely unequal.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                fig=px.box(df,x=g,y=y,points="all",title=f"Variance Comparison: {y} by {g}"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Chi-square Goodness-of-Fit" and cats:
                c=st.selectbox("Categorical column", cats); obs=df[c].value_counts(); expected_type=st.radio("Expected frequencies", ["Equal across categories", "Custom"])
                if expected_type == "Custom":
                    st.caption("Enter expected counts separated by commas in the same order shown below.")
                    st.write(list(obs.index)); custom=st.text_input("Expected counts", ",".join([str(round(obs.sum()/len(obs),2))]*len(obs)))
                    exp=np.array([float(x.strip()) for x in custom.split(",")]); exp=exp*obs.sum()/exp.sum()
                else:
                    exp=np.ones(len(obs))*obs.sum()/len(obs)
                stat,p=stats.chisquare(obs.values, f_exp=exp)
                st.write(f"χ² statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp}</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                plot=pd.DataFrame({"Category":obs.index.astype(str),"Observed":obs.values,"Expected":exp}).melt(id_vars="Category",var_name="Type",value_name="Count")
                fig=px.bar(plot,x="Category",y="Count",color="Type",barmode="group",title="Observed vs Expected Counts"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Chi-square Independence" and len(cats)>=2:
                a=st.selectbox("First categorical variable", cats); b=st.selectbox("Second categorical variable", [c for c in cats if c!=a])
                tab=pd.crosstab(df[a],df[b]); stat,p,dof,exp=stats.chi2_contingency(tab)
                st.write(f"χ² statistic: **{format_num(stat)}** | p-value: **{format_p(p)}** | dof: **{dof}**"); interp=interpret_p(p,alpha,"independence between variables"); st.markdown(f"<div class='info-box'>{interp}</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                st.dataframe(tab, use_container_width=True)
                fig=px.imshow(tab, text_auto=True, title="Contingency Table Heatmap"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Pearson Correlation" and len(nums)>=2:
                x=st.selectbox("X variable", nums); y=st.selectbox("Y variable", [c for c in nums if c!=x])
                pair=df[[x,y]].dropna(); r,p=stats.pearsonr(pair[x],pair[y])
                st.write(f"Pearson r: **{format_num(r)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha,"zero linear correlation"); st.markdown(f"<div class='info-box'>{interp} r ranges from -1 to +1 and describes the direction and strength of linear association.</div>", unsafe_allow_html=True); add_result(test,r,p,interp)
                fig=px.scatter(pair,x=x,y=y,trendline="ols",title=f"Correlation: {x} vs {y}"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Mann-Whitney U" and nums and cats:
                y=st.selectbox("Numeric/ordinal outcome", nums); g=st.selectbox("Two-group column", cats); groups=df[g].dropna().unique().tolist(); selected=st.multiselect("Select exactly two groups", groups, default=groups[:2])
                if len(selected)==2:
                    x1=clean_numeric(df[df[g]==selected[0]][y]); x2=clean_numeric(df[df[g]==selected[1]][y]); stat,p=stats.mannwhitneyu(x1,x2,alternative="two-sided")
                    st.write(f"U statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp} Mann-Whitney U is a non-parametric alternative to the independent two-sample t-test.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                    fig=px.box(df[df[g].isin(selected)],x=g,y=y,points="all",title="Mann-Whitney Group Comparison"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Wilcoxon Signed-Rank" and len(nums)>=2:
                a=st.selectbox("First paired column", nums); b=st.selectbox("Second paired column", [c for c in nums if c!=a])
                pair=df[[a,b]].dropna(); stat,p=stats.wilcoxon(pair[a],pair[b])
                st.write(f"W statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp} Wilcoxon signed-rank is a non-parametric alternative to the paired t-test.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                plot_df=pair.reset_index().melt(id_vars="index", value_vars=[a,b], var_name="Condition", value_name="Value")
                fig=px.line(plot_df,x="Condition",y="Value",color="index",markers=True,title="Wilcoxon Paired Plot"); st.plotly_chart(style_fig(fig),use_container_width=True)
            elif test == "Kruskal-Wallis" and nums and cats:
                y=st.selectbox("Numeric/ordinal outcome", nums); g=st.selectbox("Group column", cats)
                vals=[clean_numeric(df[df[g]==val][y]) for val in df[g].dropna().unique()]; vals=[v for v in vals if len(v)>1]
                stat,p=stats.kruskal(*vals)
                st.write(f"H statistic: **{format_num(stat)}** | p-value: **{format_p(p)}**"); interp=interpret_p(p,alpha); st.markdown(f"<div class='info-box'>{interp} Kruskal-Wallis is a non-parametric alternative to one-way ANOVA.</div>", unsafe_allow_html=True); add_result(test,stat,p,interp)
                fig=px.box(df,x=g,y=y,points="all",title="Kruskal-Wallis Group Comparison"); st.plotly_chart(style_fig(fig),use_container_width=True)
            else:
                st.info("This test needs compatible columns in the loaded dataset.")
        except Exception as e:
            st.error(f"Could not run the selected test: {e}")

elif page == "Test Advisor":
    st.title("Test Advisor")
    st.write("Answer a few questions and the toolkit will suggest a suitable statistical test.")
    goal=st.selectbox("What is your analysis goal?", ["Compare groups", "Test relationship/association", "Check normality", "Check equal variances", "Fit a distribution"])
    outcome=st.selectbox("Outcome variable type", ["Numerical", "Categorical", "Ordinal/Text"])
    groups=st.selectbox("How many groups/variables?", ["One", "Two", "More than two"])
    relation=st.selectbox("Are groups independent or paired?", ["Independent", "Paired / repeated", "Not applicable"])
    normal=st.selectbox("Is numerical data normally distributed?", ["Yes", "No", "Not sure"])
    recommendation=""
    alternative=""
    if goal == "Check normality":
        recommendation="Shapiro-Wilk, Kolmogorov-Smirnov, and Anderson-Darling normality tests"
        alternative="Use Q-Q plots and histograms as graphical support."
    elif goal == "Check equal variances":
        recommendation="Levene's Test"
        alternative="Inspect grouped boxplots as graphical support."
    elif goal == "Fit a distribution":
        recommendation="Distribution Lab: Normal, Uniform, and Exponential fitting using MSE"
        alternative="Use formal goodness-of-fit tests and Q-Q plots for deeper confirmation."
    elif goal == "Test relationship/association":
        if outcome == "Numerical":
            recommendation="Pearson correlation test"
            alternative="Use Spearman correlation if the relationship is non-linear or data is ordinal/non-normal."
        else:
            recommendation="Chi-square independence test"
            alternative="Use a contingency table heatmap to inspect the relationship visually."
    elif goal == "Compare groups":
        if outcome == "Categorical":
            recommendation="Chi-square independence test"
            alternative="Use observed vs expected counts for interpretation."
        elif groups == "One":
            recommendation="One-sample t-test or one-sample Z-test"
            alternative="Use Z-test only when population standard deviation is known or sample size is large."
        elif groups == "Two" and relation == "Paired / repeated":
            recommendation="Paired t-test" if normal == "Yes" else "Wilcoxon signed-rank test"
            alternative="Paired plot helps inspect before-after differences."
        elif groups == "Two" and relation == "Independent":
            recommendation="Independent two-sample t-test" if normal == "Yes" else "Mann-Whitney U test"
            alternative="Run Levene's test to check equality of variances."
        elif groups == "More than two":
            recommendation="One-way ANOVA / Two-way ANOVA" if normal == "Yes" else "Kruskal-Wallis test"
            alternative="Use two-way ANOVA when there are two categorical factors."
    st.markdown(f"<div class='feature-card'><b>Recommended test</b><p>{recommendation}</p><b>Alternative / note</b><p>{alternative}</p></div>", unsafe_allow_html=True)

elif page == "Word Cloud Lab":
    st.title("Word Cloud Lab")
    st.markdown("<div class='info-box'>Create a custom weighted word cloud without needing a dataset. Put your most important words in the high-weight box, supporting words in medium-weight, and background words in low-weight.</div>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    with c1:
        high_words = st.text_area("Highest weight words", height=180, placeholder="analytics insight decision statistics significance")
        high_weight = st.slider("High weight multiplier", 5, 15, 10)
    with c2:
        medium_words = st.text_area("Medium weight words", height=180, placeholder="visualization cleaning distribution testing probability")
        medium_weight = st.slider("Medium weight multiplier", 2, 8, 5)
    with c3:
        low_words = st.text_area("Low weight words", height=180, placeholder="data chart sample report export model")
        low_weight = st.slider("Low weight multiplier", 1, 5, 2)

    custom_stop=st.text_input("Optional stopwords to remove, separated by commas", value="")

    def expand_words(text, weight):
        text = text.lower()
        stops=set(STOPWORDS) if WORDCLOUD_AVAILABLE else set(['the','and','is','to','of','in','a','for'])
        stops.update([w.strip().lower() for w in custom_stop.split(',') if w.strip()])
        words=[w for w in re.findall(r"[a-zA-Z][a-zA-Z\-']+", text) if len(w)>1 and w not in stops]
        expanded=[]
        for w in words:
            expanded.extend([w]*weight)
        return expanded

    words = expand_words(high_words, high_weight) + expand_words(medium_words, medium_weight) + expand_words(low_words, low_weight)
    if words:
        freq=pd.Series(words).value_counts().reset_index(); freq.columns=["Word","Weighted Frequency"]
        st.session_state.wordcloud_freq = freq.copy()
        st.subheader("Weighted Word Table")
        st.caption("The app stores the complete weighted word list for the PDF report. The bar chart only shows the top words so the screen stays readable.")
        st.dataframe(freq, use_container_width=True)
        fig=px.bar(freq.head(30), x="Word", y="Weighted Frequency", title="Top Weighted Words")
        st.plotly_chart(style_fig(fig), use_container_width=True)
        if WORDCLOUD_AVAILABLE:
            wc=WordCloud(width=1600,height=800,background_color=BG,colormap="Pastel1",prefer_horizontal=0.92,collocations=False,max_words=300,margin=12,random_state=42).generate_from_frequencies(dict(zip(freq["Word"], freq["Weighted Frequency"])))
            st.image(wc.to_array(), caption="Custom Weighted Word Cloud", use_container_width=True)
        else:
            st.warning("WordCloud package is not available. Install dependencies using: pip install -r requirements.txt")
    else:
        st.info("Enter words in at least one box to generate the word cloud.")

elif page == "Report & Export":
    st.title("Report & Export")
    df = require_df()
    if df is not None:
        st.markdown("<div class='info-box'><b>One professional report. One button.</b><br>The PDF now exports the entire current toolkit output as a structured report with cover page, executive summary, data workspace, data quality, descriptive analytics, normality testing, distribution fitting, graphical outputs, stored hypothesis-test interpretations, Word Cloud Lab output, and interpretation notes.</div>", unsafe_allow_html=True)

        c1, c2, c3, c4 = st.columns(4)
        with c1: metric_card("Rows", df.shape[0])
        with c2: metric_card("Columns", df.shape[1])
        with c3: metric_card("Stored tests", len(st.session_state.get("results", [])))
        with c4: metric_card("Word cloud", "Ready" if st.session_state.get("wordcloud_freq") is not None else "Not generated")

        st.subheader("Full Analysis Report Contents")
        st.markdown(
            """
            <div class='feature-card'>
            <b>The exported PDF includes:</b>
            <p>
            1. Premium cover page and assignment identity<br>
            2. Executive summary with dataset health metrics<br>
            3. Data workspace output and dataset preview<br>
            4. Missing-value and outlier analysis<br>
            5. Descriptive statistics for numerical and categorical variables<br>
            6. Shapiro-Wilk, Kolmogorov-Smirnov, and Anderson-Darling normality outputs<br>
            7. Normal, Uniform, and Exponential distribution fitting using MSE<br>
            8. Central Limit Theorem simulation output<br>
            9. Graphical outputs including histogram, Q-Q plot, fitted-distribution comparison, and correlation heatmap<br>
            10. Stored statistical-test results with interpretations<br>
            11. Word Cloud Lab output if generated
            </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        if not st.session_state.get("results"):
            st.warning("No statistical inference outputs are stored yet. The report will still export, but run tests first if you want hypothesis-test statistics and interpretations included.")
        if st.session_state.get("wordcloud_freq") is None:
            st.info("Word Cloud Lab output is optional. Generate a word cloud first if you want it included in the PDF.")

        if REPORTLAB_AVAILABLE:
            pdf_bytes = generate_pdf_report(df)
            if pdf_bytes:
                st.download_button(
                    "Download Full ZN Analytics Report PDF",
                    data=pdf_bytes,
                    file_name="ZN_Analytics_Toolkit_Full_Report.pdf",
                    mime="application/pdf",
                    use_container_width=True,
                )
        else:
            st.warning("PDF export needs reportlab. Run: pip install reportlab")

        st.markdown("<div class='info-box'>Tip: For the strongest final submission, load/clean a dataset, run your main statistical tests, generate a word cloud, then export this full report.</div>", unsafe_allow_html=True)

elif page == "User Guide":
    st.title("User Guide")
    st.markdown(
        """
        ### How to use ZN Analytics Toolkit
        1. Open **Data Workspace** and upload a CSV/Excel file or load the sample dataset.
        2. Use **Data Quality & Cleaning** to inspect missing values, duplicates, and outliers.
        3. Use **Descriptive Analytics** and **Visual Analytics** to explore patterns.
        4. Use **Distribution Lab** to compare Normal, Uniform, and Exponential fits using MSE.
        5. Use **Normality Testing** before choosing parametric tests.
        6. Use **Statistical Inference** to run tests with statistical output, graphical output, and interpretation.
        7. Use **Test Advisor** when you are unsure which test to choose.
        8. Use **Word Cloud Lab** to create a custom weighted word cloud from direct user input.
        9. Use **Report & Export** to download cleaned datasets and analysis outputs.

        ### Sample dataset
        The included employee analytics dataset contains performance, training, satisfaction, stress, absenteeism, work model, department, promotion eligibility, and feedback data. It supports t-tests, ANOVA, two-way ANOVA, chi-square tests, correlation, normality tests, distribution fitting, Central Limit Theorem simulation, and custom word cloud analysis.

        ### Important statistical note
        The toolkit provides guided statistical analysis, but users should still consider study design, sampling method, assumptions, and domain context before making final decisions.
        """
    )
