# ZN Analytics Toolkit

**From raw data to statistical insight.**

Created by: **Naresh Punjabi**  
Course: **Tools and Methods of Data Analysis**  
University: **SRH University Leipzig**

---

## Overview

ZN Analytics Toolkit is a professional no-code data analysis dashboard built with Streamlit. It is designed for students, analysts, and users with limited programming experience who need an intuitive toolkit for data cleaning, exploration, visualization, distribution fitting, Central Limit Theorem simulation, statistical inference, and word cloud analytics.

The toolkit combines Python's statistical accuracy with an interactive dashboard interface.

---

## Main Features

### 1. Data Workspace
- Upload CSV or Excel datasets
- Load a built-in sample employee analytics dataset
- Preview data
- View row count, column count, missing cells, duplicate rows, and memory usage
- Automatically detect numeric and categorical/text columns
- Generate a column-level summary table

### 2. Data Quality & Cleaning
- Missing-value analysis
- Missing-value percentage chart
- Duplicate row detection and removal
- Drop rows with missing values
- Fill missing values using mean, median, mode, or custom values
- IQR-based outlier detection
- Boxplot outlier visualization

### 3. Descriptive Analytics
- Numerical summary statistics:
  - Mean
  - Median
  - Mode
  - Standard deviation
  - Variance
  - Minimum
  - Maximum
  - Range
  - Quartiles
  - IQR
  - Skewness
  - Kurtosis
- Categorical frequency tables
- Percentage tables
- Graphical frequency visualizations

### 4. Visual Analytics
Interactive Plotly charts:
- Histogram
- Boxplot
- Scatter plot with trendline
- Line chart
- Bar chart
- Pie chart
- Correlation heatmap
- Scatter matrix

Axis values are formatted cleanly to avoid messy recurring decimals.

### 5. Distribution Lab
- Theoretical Normal distribution PDF/CDF
- Binomial PMF/CDF
- Poisson PMF/CDF
- Exponential PDF/CDF
- Dataset distribution fitting using MSE
- Compares:
  - Normal
  - Uniform
  - Exponential
- Shows all fitted curves
- Highlights the best-fitting distribution based on lowest MSE
- Central Limit Theorem Simulator
  - Select a numeric variable
  - Choose sample size and simulation count
  - Compare the original distribution with the sampling distribution of means
  - View original mean, mean of sample means, sampling standard deviation, and theoretical standard error
  - Includes histogram and Q-Q plot output for the sampling distribution

### 6. Normality Testing
Includes three normality tests:
- Shapiro-Wilk test
- Kolmogorov-Smirnov test
- Anderson-Darling test

Outputs include:
- Test statistic
- p-value where available
- Anderson-Darling critical-value decision
- Interpretation
- Histogram with normal curve
- Q-Q plot
- Boxplot

### 7. Statistical Inference
Includes:
- Confidence interval for mean
- One-sample t-test
- Independent two-sample t-test
- Paired t-test
- One-sample and two-sample Z-test
- One-way ANOVA
- Two-way ANOVA
- Levene's test for equal variances
- Chi-square goodness-of-fit test
- Chi-square independence test
- Pearson correlation test
- Mann-Whitney U test
- Wilcoxon signed-rank test
- Kruskal-Wallis test

Each test provides:
- Statistical output
- Graphical output
- Plain-English interpretation
- Assumption reminders where relevant

### 8. Test Advisor
A guided decision helper that recommends suitable tests based on:
- Analysis goal
- Outcome variable type
- Number of groups
- Independent vs paired design
- Normality condition

### 9. Word Cloud Lab
- Create a custom word cloud directly from user input
- Separate words into highest, medium, and low-weight groups
- Adjust weight multipliers interactively
- Remove optional custom stopwords
- Display weighted frequency tables
- Visualize weighted word frequency bar charts

### 10. Report & Export
- One-click full PDF export
- Premium organized report layout
- Includes cover page, executive summary, dataset overview, data quality, descriptive analytics, normality testing, distribution fitting, Central Limit Theorem simulation, graphical outputs, stored statistical-test results, interpretations, and Word Cloud Lab outputs when generated
- Designed to look like a professional analyst report rather than a raw data dump

---

## Sample Dataset

The included dataset is `employee_analytics_sample.csv`.

It contains employee-related variables such as:

- Employee_ID
- Department
- Work_Model
- Experience_Years
- Training_Hours
- Workload_Index
- Job_Satisfaction
- Stress_Level
- Absenteeism_Days
- Performance_Score
- Promotion_Eligible
- Feedback

This dataset supports example analyses such as:

- Comparing performance across work models
- Testing whether departments differ in performance
- Running two-way ANOVA using Department and Work_Model
- Checking if promotion eligibility is associated with department
- Correlating training hours with performance score
- Testing normality of performance scores
- Comparing Normal, Uniform, and Exponential distribution fits
- Demonstrating the Central Limit Theorem using repeated sample-mean simulations
- Generating a word cloud from employee feedback

---

## How to Run Locally

### 1. Clone or download this repository

```bash
git clone <your-repository-link>
cd ZN-Analytics-Toolkit
```

### 2. Install requirements

```bash
pip install -r requirements.txt
```

### 3. Run the app

```bash
streamlit run app.py
```

The app will open in your browser.

---

## How to Deploy on Streamlit Community Cloud

1. Push this project to a public GitHub repository.
2. Go to Streamlit Community Cloud.
3. Connect your GitHub account.
4. Select this repository.
5. Set the main file path as:

```text
app.py
```

6. Deploy the app.
7. Copy the live app link and add it to this README.

---

## Repository Structure

```text
ZN-Analytics-Toolkit/
│
├── app.py
├── requirements.txt
├── README.md
├── employee_analytics_sample.csv
└── assets/
    └── screenshots/
```

---

## Technologies Used

- Python
- Streamlit
- Pandas
- NumPy
- SciPy
- Statsmodels
- Plotly
- WordCloud
- Matplotlib
- OpenPyXL

---

## Notes

This toolkit is designed for educational and analytical use. Statistical results should be interpreted with consideration of data quality, sampling method, research design, and assumptions of each test.
